/* ---------------------------------------------------------------------------

 parametersCH.c will produce CH.airebo parameter files for the AIREBO
 potential in LAMMPS. The input in this program are the published
 values, the program calculates the spline parameters.
 
 Parameters taken from:
     S. Stuart et al, J. Chem. Phys. 112, 6472 (2000)
     D. Brenner et al, J. Phys. Cond. Matt. 14, 783 (2002)
 
 Written by Colin Bousige (MIT-CNRS), Sept. 2013
 
 Compile with: gcc -o parametersCH parametersCH.c -lm -llapack -I/usr/local/Cellar/openblas/0.2.6/include/
 
--------------------------------------------------------------------------- */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <math.h> 
#include <lapacke.h>

#define PI 3.14159265359

void quinticcoef(double x, double y, double coeff[6]);
void bicubcoef(double x, double y, double f[4], double fx[4], double fy[4], double fxy[4], double coeff[4][4]);
void tricubcoef(double x, double y, double z, double f[8], double fx[8], double fy[8], double fz[8],
               double fxy[8], double fxz[8], double fyz[8], double fxyz[8], double coeff[4][4][4]);


int main()
{
    int i,j,k,l,m,n,ok,c2=1,c1,p;
    FILE *fp;
    double x,y,temp,temp2;
    /* Original CH parameters from Stuart and Brenner: */
    double rcmin_CC = 1.7;
    double rcmin_CH = 1.3;
    double rcmin_HH = 1.1;
    double rcmax_CC = 2;
    double rcmax_CH = 1.8;
    double rcmax_HH = 1.7;
    double rcmaxp_CC = 2;
    double rcmaxp_CH = 1.6;
    double rcmaxp_HH = 1.7;
    double smin = 0.1;
    double Nmin = 2;
    double Nmax = 3;
    double NCmin = 3.2;
    double NCmax = 3.7;
    double Q_CC = 0.31346;
    double Q_CH = 0.340776;
    double Q_HH = 0.370471;
    double alpha_CC = 4.7465391;
    double alpha_CH = 4.1025498;
    double alpha_HH = 3.5362986;
    double A_CC = 10953.544;
    double A_CH = 149.94099;
    double A_HH = 32.817356;
    double BIJc_CC1 = 12388.792;
    double BIJc_CC2 = 17.567065;
    double BIJc_CC3 = 30.714932;
    double BIJc_CH1 = 32.355187;
    double BIJc_CH2 = 0;
    double BIJc_CH3 = 0;
    double BIJc_HH1 = 29.632593;
    double BIJc_HH2 = 0;
    double BIJc_HH3 = 0;
    double Beta_CC1 = 4.7204523;
    double Beta_CC2 = 1.4332132;
    double Beta_CC3 = 1.3826913;
    double Beta_CH1 = 1.4344581;
    double Beta_CH2 = 0;
    double Beta_CH3 = 0;
    double Beta_HH1 = 1.7158922;
    double Beta_HH2 = 0;
    double Beta_HH3 = 0;
    double rho_CC = 0;
    double rho_CH = 1.09;
    double rho_HH = 0.7415887;
    double rcLJmin_CC = 3.4;
    double rcLJmin_CH = 3.025;
    double rcLJmin_HH = 2.65;
    double rcLJmax_CC = 3.816370964;
    double rcLJmax_CH = 3.395447696;
    double rcLJmax_HH = 2.974524428;
    double bLJmin_CC = 0.77;
    double bLJmin_CH = 0.75;
    double bLJmin_HH = 0.32;
    double bLJmax_CC = 0.81;
    double bLJmax_CH = 0.9;
    double bLJmax_HH = 0.42;
    double epsilon_CC = 0.00284;
    double epsilon_CH = 0.0020639767;
    double epsilon_HH = 0.0015;
    double sigma_CC = 3.4;
    double sigma_CH = 3.025;
    double sigma_HH = 2.65;
    double epsilonT_CCCC = 0.3079;
    double epsilonT_CCCH = 0.1787;
    double epsilonT_HCCH = 0.125;
    
    /* g quintic splines -------------------------------------------------------------------------------------------------- */
    
    int NdomainsgC = 5, NdomainsgH = 4;
    double coeffg[6];
    double evalgC[NdomainsgC],evalgH[NdomainsgH];
    double gC1i[NdomainsgC],dgC1i[NdomainsgC],d2gC1i[NdomainsgC];
    double gC2i[NdomainsgC],dgC2i[NdomainsgC],d2gC2i[NdomainsgC];
    double gHi[NdomainsgH],dgHi[NdomainsgH],d2gHi[NdomainsgH];
    
    /* Interpolation points */
    evalgC[0] = -1.;     evalgH[0] = -1.;
    evalgC[1] = -2./3.;  evalgH[1] = -5./6.;
    evalgC[2] = -1./2.;  evalgH[2] = -1./2.;
    evalgC[3] = -1./3.;  evalgH[3] = 1.;
    evalgC[4] = 1.;

    /* Values of the g function and of first and second derivative at interpolation points */
    gC1i[0] = -1.00000000E-02;	dgC1i[0] = 1.04000000E-01;	d2gC1i[0] = 0.00000000E+00;
    gC1i[1] = 2.82070000E-02;	dgC1i[1] = 1.31443000E-01;	d2gC1i[1] = 1.40229000E-01;
    gC1i[2] = 5.28040000E-02;	dgC1i[2] = 1.70000000E-01;	d2gC1i[2] = 3.70000000E-01;
    gC1i[3] = 9.73210000E-02;	dgC1i[3] = 4.00000000E-01;	d2gC1i[3] = 1.98000000E+00;
    gC1i[4] = 1.00000000E+00;	dgC1i[4] = 2.83457000E+00;	d2gC1i[4] = 1.02647000E+01;
    
    gC2i[0] = -1.00000000E-02;	dgC2i[0] = 1.04000000E-01;	d2gC2i[0] = 0.00000000E+00;
    gC2i[1] = 2.82070000E-02;	dgC2i[1] = 1.31443000E-01;	d2gC2i[1] = 1.40229000E-01;
    gC2i[2] = 5.28040000E-02;	dgC2i[2] = 1.70000000E-01;	d2gC2i[2] = 3.70000000E-01;
    gC2i[3] = 9.73210000E-02;	dgC2i[3] = 4.00000000E-01;	d2gC2i[3] = 1.98000000E+00;
    gC2i[4] = 8.00000000E+00;	dgC2i[4] = 2.02436000E+01;	d2gC2i[4] = 4.39336000E+01;
    
    gHi[0] = 1.12357000E+01;	dgHi[0] = 0.00000000E+00;	d2gHi[0] = 1.15115000E+02;
    gHi[1] = 1.25953000E+01;	dgHi[1] = 1.38543000E+01;	d2gHi[1] = 3.23618000E+01;
    gHi[2] = 1.68111000E+01;	dgHi[2] = 8.64123000E+00;	d2gHi[2] = -2.50617000E+01;
    gHi[3] = 1.99918000E+01;	dgHi[3] = 3.33013000E-01;	d2gHi[3] = -4.74189000E-01;
    
    
    /* P bicubic splines -------------------------------------------------------------------------------------------------- */
    
    int NmaxP = 4;
    double **PijCC,**PijCH,coeffP[4][4],ybc[4],y1bc[4],y2bc[4],y12bc[4];
    PijCC = calloc(6,sizeof(double*));
    PijCH = calloc(6,sizeof(double*));
    for(i=0;i<6;i++){
        PijCC[i] = calloc(6,sizeof(double));
        PijCH[i] = calloc(6,sizeof(double));
    }
    /* Values of Pij at integral points: */
    PijCC[0][2] = -0.000500;    PijCH[0][1] = 0.209337;
    PijCC[0][3] = 0.016125;     PijCH[0][2] = -0.064450;
    PijCC[1][1] = -0.010960;    PijCH[0][3] = -0.303928;
    PijCC[1][2] = 0.006326;     PijCH[1][0] = 0.010000;
    PijCC[2][0] = -0.027603;    PijCH[1][1] = -0.125123;
    PijCC[2][1] = 0.003180;     PijCH[1][2] = -0.298905;
                                PijCH[2][0] = -0.122042;
                                PijCH[2][1] = -0.300529;
                                PijCH[3][0] = -0.307585;
    
    
    /* pi and Tij tricubic splines ----------------------------------------------------------------------------------------- */
    
    int NmaxPi=6, min_tricub=0, xmax_tricub=4, ymax_tricub=4, zmax_tricub=9;
    double f[8], fx[8], fy[8], fz[8], fxy[8], fxz[8];
    double fyz[8], fxyz[8], coeffpi[4][4][4];
    double ***piCC,***piCCx,***piCCy,***piCCz,***piCH,***piCHx,***piCHy,***piCHz;
    double ***piHH,***piHHx,***piHHy,***piHHz,***Tij;
    // Initialize all values and derivatives to 0.
    piCC  = calloc(xmax_tricub+1,sizeof(double**)); // Contains values at the knots
    piCCx = calloc(xmax_tricub+1,sizeof(double**)); // Contains derivative with respect to first variable
    piCCy = calloc(xmax_tricub+1,sizeof(double**)); // Contains derivative with respect to second variable
    piCCz = calloc(xmax_tricub+1,sizeof(double**)); // Contains derivative with respect to third variable
    piHH  = calloc(xmax_tricub+1,sizeof(double**));
    piHHx = calloc(xmax_tricub+1,sizeof(double**));
    piHHy = calloc(xmax_tricub+1,sizeof(double**));
    piHHz = calloc(xmax_tricub+1,sizeof(double**));
    piCH  = calloc(xmax_tricub+1,sizeof(double**));
    piCHx = calloc(xmax_tricub+1,sizeof(double**));
    piCHy = calloc(xmax_tricub+1,sizeof(double**));
    piCHz = calloc(xmax_tricub+1,sizeof(double**));
    Tij   = calloc(xmax_tricub+1,sizeof(double**));
    for(i=0;i<6;i++){
        piCC[i]  = calloc(ymax_tricub+1,sizeof(double*));
        piCCx[i] = calloc(ymax_tricub+1,sizeof(double*));
        piCCy[i] = calloc(ymax_tricub+1,sizeof(double*));
        piCCz[i] = calloc(ymax_tricub+1,sizeof(double*));
        piHH[i]  = calloc(ymax_tricub+1,sizeof(double*));
        piHHx[i] = calloc(ymax_tricub+1,sizeof(double*));
        piHHy[i] = calloc(ymax_tricub+1,sizeof(double*));
        piHHz[i] = calloc(ymax_tricub+1,sizeof(double*));
        piCH[i]  = calloc(ymax_tricub+1,sizeof(double*));
        piCHx[i] = calloc(ymax_tricub+1,sizeof(double*));
        piCHy[i] = calloc(ymax_tricub+1,sizeof(double*));
        piCHz[i] = calloc(ymax_tricub+1,sizeof(double*));
        Tij[i]   = calloc(ymax_tricub+1,sizeof(double*));
        for(j=0;j<6;j++){
            piCC[i][j]  = calloc(zmax_tricub+2,sizeof(double));
            piCCx[i][j] = calloc(zmax_tricub+2,sizeof(double));
            piCCy[i][j] = calloc(zmax_tricub+2,sizeof(double));
            piCCz[i][j] = calloc(zmax_tricub+2,sizeof(double));
            piHH[i][j]  = calloc(zmax_tricub+2,sizeof(double));
            piHHx[i][j] = calloc(zmax_tricub+2,sizeof(double));
            piHHy[i][j] = calloc(zmax_tricub+2,sizeof(double));
            piHHz[i][j] = calloc(zmax_tricub+2,sizeof(double));
            piCH[i][j]  = calloc(zmax_tricub+2,sizeof(double));
            piCHx[i][j] = calloc(zmax_tricub+2,sizeof(double));
            piCHy[i][j] = calloc(zmax_tricub+2,sizeof(double));
            piCHz[i][j] = calloc(zmax_tricub+2,sizeof(double));
            Tij[i][j]   = calloc(zmax_tricub+2,sizeof(double));
        }
    }
    
    /* Values at knots for CC------------- */
    for(i=3;i<zmax_tricub+1;i++){
    piCC[0][0][i] = 0.004959;}
    piCC[1][0][1] = 0.021694;
    for(i=2;i<zmax_tricub+1;i++){
    piCC[1][0][i] = 0.004959;}
    piCC[1][1][1] = 0.052500;
    piCC[1][1][2] = -0.002089;
    for(i=3;i<zmax_tricub+1;i++){
    piCC[1][1][i] = -0.008043;}
    piCC[2][0][1] = 0.024699;
    piCC[2][0][2] = -0.005971;
    for(i=3;i<zmax_tricub+1;i++){
    piCC[2][0][i] = 0.004959;}
    piCC[2][1][1] = 0.004825;       piCCx[2][1][1] = -0.026250;
    piCC[2][1][2] = 0.015000;
    piCC[2][1][3] = -0.010000;
    piCC[2][1][4] = -0.011689;                                              piCCz[2][1][4] = -0.010022;
    piCC[2][1][5] = -0.013378;      piCCx[2][1][5] = -0.027188;				piCCz[2][1][5] = -0.010022;
    piCC[2][1][6] = -0.015067;      piCCx[2][1][6] = -0.027188;
    for(i=7;i<zmax_tricub+1;i++){
    piCC[2][1][i] = -0.015067;      piCCx[2][1][i] = -0.027188;}
    piCC[2][2][1] = 0.047225;
    piCC[2][2][2] = 0.011000;
    piCC[2][2][3] = 0.019853;
    piCC[2][2][4] = 0.016544;                                               piCCz[2][2][4] = -0.003309;
    piCC[2][2][5] = 0.013235;                                               piCCz[2][2][5] = -0.003309;
    piCC[2][2][6] = 0.009926;                                               piCCz[2][2][6] = -0.003309;
    piCC[2][2][7] = 0.006618;                                               piCCz[2][2][7] = -0.003309;
    piCC[2][2][8] = 0.003309;                                               piCCz[2][2][8] = -0.003309;
    piCC[3][0][1] = -0.099899;
    piCC[3][0][2] = -0.099899;
    for(i=3;i<zmax_tricub+1;i++){
    piCC[3][0][i] = 0.004959;}
    piCC[3][1][2] = -0.062418;                      piCCy[3][1][2] = 0.037545;
    for(i=3;i<zmax_tricub+1;i++){
    piCC[3][1][i] = -0.062418;}
    piCC[3][2][1] = -0.022355;
    for(i=2;i<zmax_tricub+1;i++){
    piCC[3][2][i] = -0.022355;                      piCCy[3][2][i] = 0.062418;}

    /* The values are symmetric for the two first parameters: */
    for(i=0;i<xmax_tricub;i++){
        for(j=0;j<ymax_tricub;j++){
            for(k=1;k<zmax_tricub+1;k++){
                if(piCC[i][j][k] != 0.) piCC[j][i][k] = piCC[i][j][k];
                if(piCCz[i][j][k] != 0.) piCCz[j][i][k] = piCCz[i][j][k];
                if(piCCx[i][j][k] != 0.){
                    piCCy[j][i][k] = temp;
                    piCCy[j][i][k] = piCCx[i][j][k];
                    piCCx[j][i][k] = temp;
                }
                if(piCCy[i][j][k] != 0.){
                    piCCx[j][i][k] = temp;
                    piCCx[j][i][k] = piCCy[i][j][k];
                    piCCy[j][i][k] = temp;
                }

            }
        }
    }
    
    /* Values at knots for CH--------------- */
    piCH[1][1][1] = -0.050000;
    piCH[1][1][2] = -0.050000;
    piCH[1][1][3] = -0.300000;
    for(i=4;i<zmax_tricub+1;i++){
    piCH[1][1][i] = -0.050000;}
    for(i=5;i<zmax_tricub+1;i++){
    piCH[2][0][i] = -0.004524;}
    piCH[2][1][2] = -0.250000;
    piCH[2][1][3] = -0.250000;
    piCH[3][1][1] = -0.100000;
    piCH[3][1][2] = -0.125000;
    piCH[3][1][3] = -0.125000;
    for(i=4;i<zmax_tricub+1;i++){
    piCH[3][1][i] = -0.100000;}
    /* The values are symmetric for the two first parameters: */
    for(i=0;i<xmax_tricub;i++){
        for(j=0;j<ymax_tricub;j++){
            for(k=1;k<zmax_tricub+1;k++){
                if(piCH[i][j][k] != 0.) piCH[j][i][k] = piCH[i][j][k];
                if(piCHz[i][j][k] != 0.) piCHz[j][i][k] = piCHz[i][j][k];
                if(piCHx[i][j][k] != 0.){
                    piCHy[j][i][k] = temp;
                    piCHy[j][i][k] = piCHx[i][j][k];
                    piCHx[j][i][k] = temp;
                }
                if(piCHy[i][j][k] != 0.){
                    piCHx[j][i][k] = temp;
                    piCHx[j][i][k] = piCHy[i][j][k];
                    piCHy[j][i][k] = temp;
                }
                
            }
        }
    }
    
    /* Values at knots for HH--------------- */
    piHH[1][1][1] = 0.124916;
    
    /* Values at knots for Tij-------------- */
    Tij[2][2][1] = -0.035140;
    for(i=2;i<zmax_tricub+1;i++){
    Tij[2][2][i] = -0.004048;}
    
    
    /*---------------------------------------------------------------------------------------------------------------------*/
    /*---------                                Writing the parameters file                                        ---------*/
    /*---------------------------------------------------------------------------------------------------------------------*/
    
    fp = fopen("CH.airebo","w");
    
    fprintf(fp,"# AI-REBO Brenner/Stuart potential\n");
    fprintf(fp,"# Parameters taken from:\n");
    fprintf(fp,"#     S. Stuart et al, J. Chem. Phys. 112, 6472 (2000)\n");
    fprintf(fp,"#     D. Brenner et al, J. Phys. Cond. Matt. 14, 783 (2002)\n\n");

    /* Parameters ----------------------------------------------------------*/
    
    fprintf(fp,"%20.10lf\trcmin_CC\n",rcmin_CC);
    fprintf(fp,"%20.10lf\trcmin_CH\n",rcmin_CH);
    fprintf(fp,"%20.10lf\trcmin_HH\n",rcmin_HH);
    fprintf(fp,"%20.10lf\trcmax_CC\n",rcmax_CC);
    fprintf(fp,"%20.10lf\trcmax_CH\n",rcmax_CH);
    fprintf(fp,"%20.10lf\trcmax_HH\n",rcmax_HH);
    fprintf(fp,"%20.10lf\trcmaxp_CC\n",rcmaxp_CC);
    fprintf(fp,"%20.10lf\trcmaxp_CH\n",rcmaxp_CH);
    fprintf(fp,"%20.10lf\trcmaxp_HH\n",rcmaxp_HH);
    fprintf(fp,"%20.10lf\tsmin\n",smin);
    fprintf(fp,"%20.10lf\tNmin\n",Nmin);
    fprintf(fp,"%20.10lf\tNmax\n",Nmax);
    fprintf(fp,"%20.10lf\tNCmin\n",NCmin);
    fprintf(fp,"%20.10lf\tNCmax\n",NCmax);
    fprintf(fp,"%20.10lf\tQ_CC\n",Q_CC);
    fprintf(fp,"%20.10lf\tQ_CH\n",Q_CH);
    fprintf(fp,"%20.10lf\tQ_HH\n",Q_HH);
    fprintf(fp,"%20.10lf\talpha_CC\n",alpha_CC);
    fprintf(fp,"%20.10lf\talpha_CH\n",alpha_CH);
    fprintf(fp,"%20.10lf\talpha_HH\n",alpha_HH);
    fprintf(fp,"%20.10lf\tA_CC\n",A_CC);
    fprintf(fp,"%20.10lf\tA_CH\n",A_CH);
    fprintf(fp,"%20.10lf\tA_HH\n",A_HH);
    fprintf(fp,"%20.10lf\tBIJc_CC1\n",BIJc_CC1);
    fprintf(fp,"%20.10lf\tBIJc_CC2\n",BIJc_CC2);
    fprintf(fp,"%20.10lf\tBIJc_CC3\n",BIJc_CC3);
    fprintf(fp,"%20.10lf\tBIJc_CH1\n",BIJc_CH1);
    fprintf(fp,"%20.10lf\tBIJc_CH2\n",BIJc_CH2);
    fprintf(fp,"%20.10lf\tBIJc_CH3\n",BIJc_CH3);
    fprintf(fp,"%20.10lf\tBIJc_HH1\n",BIJc_HH1);
    fprintf(fp,"%20.10lf\tBIJc_HH2\n",BIJc_HH2);
    fprintf(fp,"%20.10lf\tBIJc_HH3\n",BIJc_HH3);
    fprintf(fp,"%20.10lf\tBeta_CC1\n",Beta_CC1);
    fprintf(fp,"%20.10lf\tBeta_CC2\n",Beta_CC2);
    fprintf(fp,"%20.10lf\tBeta_CC3\n",Beta_CC3);
    fprintf(fp,"%20.10lf\tBeta_CH1\n",Beta_CH1);
    fprintf(fp,"%20.10lf\tBeta_CH2\n",Beta_CH2);
    fprintf(fp,"%20.10lf\tBeta_CH3\n",Beta_CH3);
    fprintf(fp,"%20.10lf\tBeta_HH1\n",Beta_HH1);
    fprintf(fp,"%20.10lf\tBeta_HH2\n",Beta_HH2);
    fprintf(fp,"%20.10lf\tBeta_HH3\n",Beta_HH3);
    fprintf(fp,"%20.10lf\trho_CC\n",rho_CC);
    fprintf(fp,"%20.10lf\trho_CH\n",rho_CH);
    fprintf(fp,"%20.10lf\trho_HH\n",rho_HH);
    /* LJ parameters --------------------*/
    fprintf(fp,"%20.10lf\trcLJmin_CC\n",rcLJmin_CC);
    fprintf(fp,"%20.10lf\trcLJmin_CH\n",rcLJmin_CH);
    fprintf(fp,"%20.10lf\trcLJmin_HH\n",rcLJmin_HH);
    fprintf(fp,"%20.10lf\trcLJmax_CC\n",rcLJmax_CC);
    fprintf(fp,"%20.10lf\trcLJmax_CH\n",rcLJmax_CH);
    fprintf(fp,"%20.10lf\trcLJmax_HH\n",rcLJmax_HH);
    fprintf(fp,"%20.10lf\tbLJmin_CC\n",bLJmin_CC);
    fprintf(fp,"%20.10lf\tbLJmin_CH\n",bLJmin_CH);
    fprintf(fp,"%20.10lf\tbLJmin_HH\n",bLJmin_HH);
    fprintf(fp,"%20.10lf\tbLJmax_CC\n",bLJmax_CC);
    fprintf(fp,"%20.10lf\tbLJmax_CH\n",bLJmax_CH);
    fprintf(fp,"%20.10lf\tbLJmax_HH\n",bLJmax_HH);
    fprintf(fp,"%20.10lf\tepsilon_CC\n",epsilon_CC);
    fprintf(fp,"%20.10lf\tepsilon_CH\n",epsilon_CH);
    fprintf(fp,"%20.10lf\tepsilon_HH\n",epsilon_HH);
    fprintf(fp,"%20.10lf\tsigma_CC\n",sigma_CC);
    fprintf(fp,"%20.10lf\tsigma_CH\n",sigma_CH);
    fprintf(fp,"%20.10lf\tsigma_HH\n",sigma_HH);
    fprintf(fp,"%20.10lf\tepsilonT_CCCC\n",epsilonT_CCCC);
    fprintf(fp,"%20.10lf\tepsilonT_CCCH\n",epsilonT_CCCH);
    fprintf(fp,"%20.10lf\tepsilonT_HCCH\n",epsilonT_HCCH);

    /* g quintic spline -------------------------------------------------------------*/
    
    fprintf(fp,"\n# gC1 and gC2\n\n");
    fprintf(fp,"%d\n",NdomainsgC);
    for(i=0;i<NdomainsgC;i++){
        fprintf(fp,"%3.10lf\n",evalgC[i]);
    }
    fprintf(fp,"\n");
    for(i=0;i<NdomainsgC-1;i++){
        x = evalgC[i];
        y = evalgC[i+1];
        coeffg[0] = gC1i[i];
        coeffg[1] = gC1i[i+1];
        coeffg[2] = dgC1i[i];
        coeffg[3] = dgC1i[i+1];
        coeffg[4] = d2gC1i[i];
        coeffg[5] = d2gC1i[i+1];
        quinticcoef(x,y,coeffg);
        for(j=0;j<6;j++){
            fprintf(fp,"%20.10lf\n", coeffg[j]);
        }
    }
    fprintf(fp,"\n");
    for(i=0;i<NdomainsgC-1;i++){
        x = evalgC[i];
        y = evalgC[i+1];
        coeffg[0] = gC2i[i];
        coeffg[1] = gC2i[i+1];
        coeffg[2] = dgC2i[i];
        coeffg[3] = dgC2i[i+1];
        coeffg[4] = d2gC2i[i];
        coeffg[5] = d2gC2i[i+1];
        quinticcoef(x,y,coeffg);
        for(j=0;j<6;j++){
            fprintf(fp,"%20.10lf\n", coeffg[j]);
        }

    }
    fprintf(fp,"\n# gH\n\n");
    fprintf(fp,"%d\n",NdomainsgH);
    for(i=0;i<NdomainsgH;i++){
        fprintf(fp,"%3.10lf\n",evalgH[i]);
    }
    fprintf(fp,"\n");
    for(i=0;i<NdomainsgH-1;i++){
        x = evalgH[i];
        y = evalgH[i+1];
        coeffg[0] = gHi[i];
        coeffg[1] = gHi[i+1];
        coeffg[2] = dgHi[i];
        coeffg[3] = dgHi[i+1];
        coeffg[4] = d2gHi[i];
        coeffg[5] = d2gHi[i+1];
        quinticcoef(x,y,coeffg);
        for(j=0;j<6;j++){
            fprintf(fp,"%20.10lf\n", coeffg[j]);
        }
    }
    fprintf(fp,"\n");
    
    
    /* P bicubic splines -------------------------------------------------------------*/
    
    fprintf(fp,"# pCC\n\n");
    fprintf(fp,"%d\n",NmaxP);
    fprintf(fp,"%3.10lf\n",0.);
    fprintf(fp,"%3.10lf\n",1.0*NmaxP);
    fprintf(fp,"%3.10lf\n",0.);
    fprintf(fp,"%3.10lf\n",1.0*NmaxP);
    fprintf(fp,"\n");
    
    for(i=0;i<NmaxP;i++){
        for(j=0;j<NmaxP;j++){
            p = 0;
            for(l=0;l<2;l++){
                for(m=0;m<2;m++){
                    ybc[p]   = PijCC[i+l][j+m];
                    y1bc[p]  = 0.;
                    y2bc[p]  = 0.;
                    y12bc[p] = 0.;
                    p++;
                }
            }
            bicubcoef(1.*i,1.*j,ybc,y1bc,y2bc,y12bc,coeffP);
            for(k=0;k<4;k++){
                for(l=0;l<4;l++){
                    fprintf(fp,"%20.10lf\n", coeffP[k][l]);
                }
            }
        }
    }
    fprintf(fp,"\n");
    fprintf(fp,"# pCH\n\n");
    fprintf(fp,"%d\n",NmaxP);
    fprintf(fp,"%3.10lf\n",0.);
    fprintf(fp,"%3.10lf\n",1.0*NmaxP);
    fprintf(fp,"%3.10lf\n",0.);
    fprintf(fp,"%3.10lf\n",1.0*NmaxP);
    fprintf(fp,"\n");

    for(i=0;i<NmaxP;i++){
        for(j=0;j<NmaxP;j++){
            p = 0;
            for(l=0;l<2;l++){
                for(m=0;m<2;m++){
                    ybc[p]   = PijCH[i+l][j+m];
                    y1bc[p]  = 0.;
                    y2bc[p]  = 0.;
                    y12bc[p] = 0.;
                    p++;
                }
            }
            bicubcoef(1.*i,1.*j,ybc,y1bc,y2bc,y12bc,coeffP);
            for(k=0;k<4;k++){
                for(l=0;l<4;l++){
                    fprintf(fp,"%20.10lf\n", coeffP[k][l]);
                }
            }
        }
    }
    
    
    /* pi tricubic splines -------------------------------------------------------------*/
    
    fprintf(fp,"\n");
    fprintf(fp,"# piCC\n\n");
    fprintf(fp,"%d\n",NmaxPi);
    fprintf(fp,"%3.10lf\n",1.0*min_tricub);
    fprintf(fp,"%3.10lf\n",1.0*xmax_tricub);
    fprintf(fp,"%3.10lf\n",1.0*min_tricub);
    fprintf(fp,"%3.10lf\n",1.0*ymax_tricub);
    fprintf(fp,"%3.10lf\n",1.0*min_tricub);
    fprintf(fp,"%3.10lf\n",1.0*zmax_tricub);
    fprintf(fp,"\n");
    for(i=0;i<xmax_tricub;i++){
        for(j=0;j<ymax_tricub;j++){
            for(k=0;k<zmax_tricub;k++){
                p = 0;
                for(l=0;l<2;l++){
                    for(m=0;m<2;m++){
                        for(n=0;n<2;n++){
                            f[p]    = piCC[i+l][j+m][k+n];
                            fx[p]   = piCCx[i+l][j+m][k+n];
                            fy[p]   = piCCy[i+l][j+m][k+n];
                            fz[p]   = piCCz[i+l][j+m][k+n];
                            fxy[p]  = 0.;
                            fxz[p]  = 0.;
                            fyz[p]  = 0.;
                            fxyz[p] = 0.;
                            p++;
                        }
                    }
                }
                tricubcoef(1.*i,1.*j,1.*k,f,fx,fy,fz,fxy,fxz,fyz,fxyz,coeffpi);
                for(l=0;l<4;l++){
                    for(m=0;m<4;m++){
                        for(n=0;n<4;n++){
                            fprintf(fp,"%20.10lf\n",coeffpi[l][m][n]);
                        }
                    }
                }
            }
        }
    }
    fprintf(fp,"\n");
    fprintf(fp,"# piCH\n\n");
    fprintf(fp,"%d\n",NmaxPi);
    fprintf(fp,"%3.10lf\n",1.0*min_tricub);
    fprintf(fp,"%3.10lf\n",1.0*xmax_tricub);
    fprintf(fp,"%3.10lf\n",1.0*min_tricub);
    fprintf(fp,"%3.10lf\n",1.0*ymax_tricub);
    fprintf(fp,"%3.10lf\n",1.0*min_tricub);
    fprintf(fp,"%3.10lf\n",1.0*zmax_tricub);
    fprintf(fp,"\n");
    for(i=0;i<xmax_tricub;i++){
        for(j=0;j<ymax_tricub;j++){
            for(k=0;k<zmax_tricub;k++){
                p = 0;
                for(l=0;l<2;l++){
                    for(m=0;m<2;m++){
                        for(n=0;n<2;n++){
                            f[p]    = piCH[i+l][j+m][k+n];
                            fx[p]   = piCHx[i+l][j+m][k+n];
                            fy[p]   = piCHy[i+l][j+m][k+n];
                            fz[p]   = piCHz[i+l][j+m][k+n];
                            fxy[p]  = 0.;
                            fxz[p]  = 0.;
                            fyz[p]  = 0.;
                            fxyz[p] = 0.;
                            p++;
                        }
                    }
                }
                tricubcoef(1.*i,1.*j,1.*k,f,fx,fy,fz,fxy,fxz,fyz,fxyz,coeffpi);
                for(l=0;l<4;l++){
                    for(m=0;m<4;m++){
                        for(n=0;n<4;n++){
                            fprintf(fp,"%20.10lf\n",coeffpi[l][m][n]);
                        }
                    }
                }
            }
        }
    }
    fprintf(fp,"\n");
    fprintf(fp,"# piHH\n\n");
    fprintf(fp,"%d\n",NmaxPi);
    fprintf(fp,"%3.10lf\n",1.0*min_tricub);
    fprintf(fp,"%3.10lf\n",1.0*xmax_tricub);
    fprintf(fp,"%3.10lf\n",1.0*min_tricub);
    fprintf(fp,"%3.10lf\n",1.0*ymax_tricub);
    fprintf(fp,"%3.10lf\n",1.0*min_tricub);
    fprintf(fp,"%3.10lf\n",1.0*zmax_tricub);
    fprintf(fp,"\n");
    for(i=0;i<xmax_tricub;i++){
        for(j=0;j<ymax_tricub;j++){
            for(k=0;k<zmax_tricub;k++){
                p = 0;
                for(l=0;l<2;l++){
                    for(m=0;m<2;m++){
                        for(n=0;n<2;n++){
                            f[p]    = piHH[i+l][j+m][k+n];
                            fx[p]   = piHHx[i+l][j+m][k+n];
                            fy[p]   = piHHy[i+l][j+m][k+n];
                            fz[p]   = piHHz[i+l][j+m][k+n];
                            fxy[p]  = 0.;
                            fxz[p]  = 0.;
                            fyz[p]  = 0.;
                            fxyz[p] = 0.;
                            p++;
                        }
                    }
                }
                tricubcoef(1.*i,1.*j,1.*k,f,fx,fy,fz,fxy,fxz,fyz,fxyz,coeffpi);
                for(l=0;l<4;l++){
                    for(m=0;m<4;m++){
                        for(n=0;n<4;n++){
                            fprintf(fp,"%20.10lf\n",coeffpi[l][m][n]);
                        }
                    }
                }
            }
        }
    }
    fprintf(fp,"\n");
    fprintf(fp,"# Tij\n\n");
    fprintf(fp,"%d\n",NmaxPi);
    fprintf(fp,"%3.10lf\n",1.0*min_tricub);
    fprintf(fp,"%3.10lf\n",1.0*xmax_tricub);
    fprintf(fp,"%3.10lf\n",1.0*min_tricub);
    fprintf(fp,"%3.10lf\n",1.0*ymax_tricub);
    fprintf(fp,"%3.10lf\n",1.0*min_tricub);
    fprintf(fp,"%3.10lf\n",1.0*zmax_tricub);
    fprintf(fp,"\n");
    for(i=0;i<xmax_tricub;i++){
        for(j=0;j<ymax_tricub;j++){
            for(k=0;k<zmax_tricub;k++){
                p = 0;
                for(l=0;l<2;l++){
                    for(m=0;m<2;m++){
                        for(n=0;n<2;n++){
                            f[p]    = Tij[i+l][j+m][k+n];
                            fx[p]   = 0.;
                            fy[p]   = 0.;
                            fz[p]   = 0.;
                            fxy[p]  = 0.;
                            fxz[p]  = 0.;
                            fyz[p]  = 0.;
                            fxyz[p] = 0.;
                            p++;
                        }
                    }
                }
                tricubcoef(1.*i,1.*j,1.*k,f,fx,fy,fz,fxy,fxz,fyz,fxyz,coeffpi);
                for(l=0;l<4;l++){
                    for(m=0;m<4;m++){
                        for(n=0;n<4;n++){
                            fprintf(fp,"%20.10lf\n",coeffpi[l][m][n]);
                        }
                    }
                }
            }
        }
    }
    fprintf(fp,"\n");

    
    
    
    fclose(fp);
    
    return 0;
}// end main



/*-------------------------------------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------------------------------------*/
/*-------------------------------------------------------------------------------------------------------*/



/*
 quinticcoef computes the quintic spline coefficients, given the 6 values of f 
 and its two first derivatives evaluated in points x and y.
*/
void quinticcoef(double x, double y, double coeff[6]){
    int k,l,c1=6,c2=1,pivot[6],ok;
    double A[6][6],AT[6*6];
    
    A[0][0] = 1; A[0][1] = x; A[0][2] = x*x; A[0][3] = x*x*x; A[0][4] = x*x*x*x; A[0][5] = x*x*x*x*x;
    A[1][0] = 1; A[1][1] = y; A[1][2] = y*y; A[1][3] = y*y*y; A[1][4] = y*y*y*y; A[1][5] = y*y*y*y*y;
    A[2][0] = 0; A[2][1] = 1; A[2][2] = 2*x; A[2][3] = 3*x*x; A[2][4] = 4*x*x*x; A[2][5] = 5*x*x*x*x;
    A[3][0] = 0; A[3][1] = 1; A[3][2] = 2*y; A[3][3] = 3*y*y; A[3][4] = 4*y*y*y; A[3][5] = 5*y*y*y*y;
    A[4][0] = 0; A[4][1] = 0; A[4][2] = 2  ; A[4][3] = 6*x  ; A[4][4] = 12*x*x ; A[4][5] = 20*x*x*x;
    A[5][0] = 0; A[5][1] = 0; A[5][2] = 2  ; A[5][3] = 6*y  ; A[5][4] = 12*y*y ; A[5][5] = 20*y*y*y;
    
    for (k=0; k<6; k++){ /* to call a Fortran routine from C we have to transform the matrix */
        for(l=0; l<6; l++) AT[l+6*k] = A[l][k];
    }
    dgesv_(&c1, &c2, AT, &c1, pivot, coeff, &c1, &ok);
}


/*
  bicubcoef computes the bicubic spline coefficients given the value f in the 4 knots (xmin,ymin),
  (xmax,ymin), (xmax,ymax), (xmin,ymax), the first derivative along x and y, resp. fx and fy,
  and the cross second derivative fxy.
*/
void bicubcoef(double x, double y, double f[4], double fx[4], double fy[4], double fxy[4], double coeff[4][4]){
    int i,j,k,l,m,n,p;
    int ok,c1=16,c2=1,pivot[16]; // needed for the matrix inversion
    double A[16][16],B[16],AT[16*16];
    
    for (i=0; i<16; i++){ // Initialization of the matrixes
        for(j=0; j<16; j++){
            A[i][j] = 0.;
            B[i] = 0;
        }
    }
    
    /* Constraints */
    for(i=0;i<4;i++)  {B[i] = f[i];}
    for(i=4;i<8;i++)  {B[i] = fx[i-4];}
    for(i=8;i<12;i++) {B[i] = fy[i-8];}
    for(i=12;i<16;i++){B[i] = fxy[i-12];}

/*
    16x16 matrix A to inverse to solve A x coef = B
    (due to how dgesv_ works, the parameters end up being stored in B)
*/
    p = 0;
    for(i=0;i<2;i++){
        for(j=0;j<2;j++){
            for(l=0;l<4;l++){
                for(m=0;m<4;m++){
                    A[p][m+4*l] = pow(x+i,l)*pow(y+j,m);
            }   }
            p++;
    }   }
    for(i=0;i<2;i++){
        for(j=0;j<2;j++){
            for(l=1;l<4;l++){
                for(m=0;m<4;m++){
                    A[p][m+4*l] = l*pow(x+i,l-1)*pow(y+j,m);
            }   }
            p++;
    }   }
    for(i=0;i<2;i++){
        for(j=0;j<2;j++){
            for(l=0;l<4;l++){
                for(m=1;m<4;m++){
                    A[p][m+4*l] = m*pow(x+i,l)*pow(y+j,m-1);
            }   }
            p++;
    }   }
    for(i=0;i<2;i++){
        for(j=0;j<2;j++){
            for(l=1;l<4;l++){
                for(m=1;m<4;m++){
                    A[p][m+4*l] = l*m*pow(x+i,l-1)*pow(y+j,m-1);
            }   }
            p++;
    }   }
    
    
    for(k=0; k<16; k++){ /* to call a Fortran routine from C we have to transform the matrix */
        for(l=0; l<16; l++){
            AT[l+16*k] = A[l][k];
        }
    }
    dgesv_(&c1, &c2, AT, &c1, pivot, B, &c1, &ok);
    
    for(l=0;l<4;l++){
        for(m=0;m<4;m++){
            coeff[l][m] = B[m+4*l];
        }
    }
}


/*
 tricubcoef calculates the coefficients of a tricubic spline, given
 the values of the function (f), the first deriviatives in each
 direction (fx, fy, fz), the mixed second derivatives (fxy, fxz,fyz), 
 and the mixed third derivative (fxyz) at each of the 8 knots of a cube of size 1.
*/

void tricubcoef(double x, double y, double z, double f[8], double fx[8], double fy[8], double fz[8],
               double fxy[8], double fxz[8], double fyz[8], double fxyz[8], double coeff[4][4][4]){
    int i,j,k,l,m,n,p;
    int ok,c1=64,c2=1,pivot[64]; // needed for the matrix inversion
    double A[64][64],B[64],AT[64*64];
    
    for (i=0; i<64; i++){ // Initialization of the matrixes
        for(j=0; j<64; j++){
            A[i][j] = 0.;
            B[i] = 0;
        }
    }
    
    /* Constraints */
    for(i=0;i<8;i++)  {B[i] = f[i];}
    for(i=8;i<16;i++) {B[i] = fx[i-8];}
    for(i=16;i<24;i++){B[i] = fy[i-16];}
    for(i=24;i<32;i++){B[i] = fz[i-24];}
    for(i=32;i<40;i++){B[i] = fxy[i-32];}
    for(i=40;i<48;i++){B[i] = fxz[i-40];}
    for(i=48;i<56;i++){B[i] = fyz[i-48];}
    for(i=56;i<64;i++){B[i] = fxyz[i-56];}
        
        
/*
    64x64 matrix A to inverse to solve A x coef = B
    (due to how dgesv_ works, the parameters end up being stored in B) 
*/
    p = 0;
    for(i=0;i<2;i++){
        for(j=0;j<2;j++){
            for(k=0;k<2;k++){
                for(l=0;l<4;l++){
                    for(m=0;m<4;m++){
                        for(n=0;n<4;n++){
                            A[p][n+4*(m+4*l)] = pow(x+i,l)*pow(y+j,m)*pow(z+k,n);
                }   }   }
                p++;
    }   }   }
    for(i=0;i<2;i++){// df/dx
        for(j=0;j<2;j++){
            for(k=0;k<2;k++){
                for(l=1;l<4;l++){
                    for(m=0;m<4;m++){
                        for(n=0;n<4;n++){
                            A[p][n+4*(m+4*l)] = l*pow(x+i,l-1)*pow(y+j,m)*pow(z+k,n);
                }   }   }
                p++;
    }   }   }
    for(i=0;i<2;i++){// df/dy
        for(j=0;j<2;j++){
            for(k=0;k<2;k++){
                for(l=0;l<4;l++){
                    for(m=1;m<4;m++){
                        for(n=0;n<4;n++){
                            A[p][n+4*(m+4*l)] = m*pow(x+i,l)*pow(y+j,m-1)*pow(z+k,n);
                        }   }   }
                p++;
            }   }   }
    for(i=0;i<2;i++){// df/dz
        for(j=0;j<2;j++){
            for(k=0;k<2;k++){
                for(l=0;l<4;l++){
                    for(m=0;m<4;m++){
                        for(n=1;n<4;n++){
                            A[p][n+4*(m+4*l)] = n*pow(x+i,l)*pow(y+j,m)*pow(z+k,n-1);
                }   }   }
                p++;
    }   }   }
    for(i=0;i<2;i++){// d2f/dxdy
        for(j=0;j<2;j++){
            for(k=0;k<2;k++){
                for(l=1;l<4;l++){
                    for(m=1;m<4;m++){
                        for(n=0;n<4;n++){
                            A[p][n+4*(m+4*l)] = l*m*pow(x+i,l-1)*pow(y+j,m-1)*pow(z+k,n);
                }   }   }
                p++;
    }   }   }
    for(i=0;i<2;i++){// d2f/dxdz
        for(j=0;j<2;j++){
            for(k=0;k<2;k++){
                for(l=1;l<4;l++){
                    for(m=0;m<4;m++){
                        for(n=1;n<4;n++){
                            A[p][n+4*(m+4*l)] = l*n*pow(x+i,l-1)*pow(y+j,m)*pow(z+k,n-1);
                }   }   }
                p++;
    }   }   }
    for(i=0;i<2;i++){// d2f/dydz
        for(j=0;j<2;j++){
            for(k=0;k<2;k++){
                for(l=0;l<4;l++){
                    for(m=1;m<4;m++){
                        for(n=1;n<4;n++){
                            A[p][n+4*(m+4*l)] = m*n*pow(x+i,l)*pow(y+j,m-1)*pow(z+k,n-1);
                }   }   }
                p++;
    }   }   }
    for(i=0;i<2;i++){// d3f/dxdydz
        for(j=0;j<2;j++){
            for(k=0;k<2;k++){
                for(l=1;l<4;l++){
                    for(m=1;m<4;m++){
                        for(n=1;n<4;n++){
                            A[p][n+4*(m+4*l)] = l*m*n*pow(x+i,l-1)*pow(y+j,m-1)*pow(z+k,n-1);
                }   }   }
                p++;
    }   }   }
        
    
    for (k=0; k<64; k++){ /* to call a Fortran routine from C we have to transform the matrix */
        for(l=0; l<64; l++){
            AT[l+64*k] = A[l][k];
        }
    }
    dgesv_(&c1, &c2, AT, &c1, pivot, B, &c1, &ok);
    
    for(l=0;l<4;l++){
        for(m=0;m<4;m++){
            for(n=0;n<4;n++){
                coeff[l][m][n] = B[n+4*(m+4*l)];
            }
        }
    }
}







